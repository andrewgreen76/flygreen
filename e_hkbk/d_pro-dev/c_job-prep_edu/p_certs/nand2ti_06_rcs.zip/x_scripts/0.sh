emacs hack_assembler.py
python3 hack_assembler.py Pong.asm

